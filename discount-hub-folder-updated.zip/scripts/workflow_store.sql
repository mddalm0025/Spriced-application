-- Table: public.workflow_store

-- DROP TABLE IF EXISTS public.workflow_store;

CREATE TABLE IF NOT EXISTS public.workflow_store
(
    is_enabled boolean,
    workflow_version character varying(255) COLLATE pg_catalog."default",
    workflow_id character varying(255) COLLATE pg_catalog."default",
    is_active boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    workflows jsonb,
    workflow_type character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_workflow_store PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_workflow_store UNIQUE (workflow_version, workflow_id, workflow_type, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.workflow_store
    OWNER to postgres;

REVOKE ALL ON TABLE public.workflow_store FROM "simai-dev";

GRANT ALL ON TABLE public.workflow_store TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.workflow_store TO "simai-dev";

GRANT ALL ON TABLE public.workflow_store TO "simai-devops";

GRANT ALL ON TABLE public.workflow_store TO simai_app;

GRANT ALL ON TABLE public.workflow_store TO zabbix;
