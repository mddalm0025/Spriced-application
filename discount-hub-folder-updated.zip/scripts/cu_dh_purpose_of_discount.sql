-- Table: public.cu_dh_purpose_of_discount

-- DROP TABLE IF EXISTS public.cu_dh_purpose_of_discount;

CREATE TABLE IF NOT EXISTS public.cu_dh_purpose_of_discount
(
    purpose_of_discount character varying(100) COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    active_flag character varying(100) COLLATE pg_catalog."default",
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_cu_dh_purpose_of_discount PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_cu_dh_purpose_of_discount UNIQUE (purpose_of_discount),
    CONSTRAINT uq_cols_cu_dh_purpose_of_discount UNIQUE (purpose_of_discount, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.cu_dh_purpose_of_discount
    OWNER to postgres;

REVOKE ALL ON TABLE public.cu_dh_purpose_of_discount FROM "simai-dev";

GRANT ALL ON TABLE public.cu_dh_purpose_of_discount TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.cu_dh_purpose_of_discount TO "simai-dev";

GRANT ALL ON TABLE public.cu_dh_purpose_of_discount TO "simai-devops";

GRANT ALL ON TABLE public.cu_dh_purpose_of_discount TO simai_app;

GRANT ALL ON TABLE public.cu_dh_purpose_of_discount TO zabbix;
-- Index: uq_cu_dh_purpose_of_discount_purpose_of_discount

-- DROP INDEX IF EXISTS public.uq_cu_dh_purpose_of_discount_purpose_of_discount;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_purpose_of_discount_purpose_of_discount
    ON public.cu_dh_purpose_of_discount USING btree
    (purpose_of_discount COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_cu_dh_purpose_of_discount_uuid

-- DROP INDEX IF EXISTS public.uq_cu_dh_purpose_of_discount_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_purpose_of_discount_uuid
    ON public.cu_dh_purpose_of_discount USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
