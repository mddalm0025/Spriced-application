-- Table: public.notification_template

-- DROP TABLE IF EXISTS public.notification_template;

CREATE TABLE IF NOT EXISTS public.notification_template
(
    notification_type character varying(255) COLLATE pg_catalog."default",
    template_config jsonb,
    source_service character varying(100) COLLATE pg_catalog."default",
    is_active boolean,
    user_roles jsonb,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(40) COLLATE pg_catalog."default" NOT NULL,
    event_type character varying(100) COLLATE pg_catalog."default",
    retry_count integer,
    updated_by character varying(255) COLLATE pg_catalog."default",
    template_id character varying(50) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    status character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_notification_template PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_notification_template UNIQUE (template_id),
    CONSTRAINT uq_cols_notification_template UNIQUE (uuid, template_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.notification_template
    OWNER to postgres;

REVOKE ALL ON TABLE public.notification_template FROM "simai-dev";

GRANT ALL ON TABLE public.notification_template TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.notification_template TO "simai-dev";

GRANT ALL ON TABLE public.notification_template TO "simai-devops";

GRANT ALL ON TABLE public.notification_template TO simai_app;

GRANT ALL ON TABLE public.notification_template TO zabbix;
-- Index: uq_notification_template_template_id

-- DROP INDEX IF EXISTS public.uq_notification_template_template_id;

CREATE UNIQUE INDEX IF NOT EXISTS uq_notification_template_template_id
    ON public.notification_template USING btree
    (template_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_notification_template_uuid

-- DROP INDEX IF EXISTS public.uq_notification_template_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_notification_template_uuid
    ON public.notification_template USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
