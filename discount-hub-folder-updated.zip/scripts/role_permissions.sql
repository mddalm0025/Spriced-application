-- Table: public.role_permissions

-- DROP TABLE IF EXISTS public.role_permissions;

CREATE TABLE IF NOT EXISTS public.role_permissions
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    roles character varying(255) COLLATE pg_catalog."default" NOT NULL,
    permissions jsonb,
    uuid character varying COLLATE pg_catalog."default",
    created_by character varying(100) COLLATE pg_catalog."default",
    updated_by character varying(100) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    permission_config jsonb,
    CONSTRAINT role_permissions_pkey PRIMARY KEY (id),
    CONSTRAINT role_permissions_roles_unique UNIQUE (roles)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.role_permissions
    OWNER to postgres;

REVOKE ALL ON TABLE public.role_permissions FROM "simai-dev";

GRANT ALL ON TABLE public.role_permissions TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.role_permissions TO "simai-dev";

GRANT ALL ON TABLE public.role_permissions TO "simai-devops";

GRANT ALL ON TABLE public.role_permissions TO simai_app;

GRANT ALL ON TABLE public.role_permissions TO zabbix;
-- Index: uq_bk_role_permissions_roles

-- DROP INDEX IF EXISTS public.uq_bk_role_permissions_roles;

CREATE UNIQUE INDEX IF NOT EXISTS uq_bk_role_permissions_roles
    ON public.role_permissions USING btree
    (roles COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_role_permissions_roles

-- DROP INDEX IF EXISTS public.uq_role_permissions_roles;

CREATE UNIQUE INDEX IF NOT EXISTS uq_role_permissions_roles
    ON public.role_permissions USING btree
    (roles COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_role_permissions_uuid

-- DROP INDEX IF EXISTS public.uq_role_permissions_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_role_permissions_uuid
    ON public.role_permissions USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
