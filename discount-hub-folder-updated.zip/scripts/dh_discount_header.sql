-- Table: public.dh_discount_header

-- DROP TABLE IF EXISTS public.dh_discount_header;

CREATE TABLE IF NOT EXISTS public.dh_discount_header
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    discount_request_id character varying(255) COLLATE pg_catalog."default" DEFAULT lpad((nextval('discount_request_sequence'::regclass))::text, 3, '0'::text),
    template_id character varying(255) COLLATE pg_catalog."default",
    requestor_name character varying(255) COLLATE pg_catalog."default",
    region character varying(100) COLLATE pg_catalog."default",
    business_unit character varying(100) COLLATE pg_catalog."default",
    pdc character varying(100) COLLATE pg_catalog."default",
    pricing_admin_owner character varying(100) COLLATE pg_catalog."default",
    dr_category character varying(100) COLLATE pg_catalog."default",
    type_of_customer character varying(100) COLLATE pg_catalog."default",
    product_bu character varying(100) COLLATE pg_catalog."default",
    application character varying(100) COLLATE pg_catalog."default",
    discount_effective_year character varying(50) COLLATE pg_catalog."default",
    purpose_of_discount character varying(255) COLLATE pg_catalog."default",
    customer_selection_type character varying(100) COLLATE pg_catalog."default",
    discount_type character varying(100) COLLATE pg_catalog."default",
    header_approval_status character varying(100) COLLATE pg_catalog."default",
    header_approvers_list jsonb,
    total_computed_impact numeric,
    approval_history jsonb,
    approved_by character varying(100) COLLATE pg_catalog."default",
    rejection_reason character varying(200) COLLATE pg_catalog."default",
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    approval_status character varying COLLATE pg_catalog."default",
    CONSTRAINT pk_dh_discount_header PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_discount_header UNIQUE (business_unit, pdc, discount_request_id, region)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_discount_header
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_discount_header FROM "simai-dev";

GRANT ALL ON TABLE public.dh_discount_header TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_discount_header TO "simai-dev";

GRANT ALL ON TABLE public.dh_discount_header TO "simai-devops";

GRANT ALL ON TABLE public.dh_discount_header TO simai_app;

GRANT ALL ON TABLE public.dh_discount_header TO zabbix;
-- Index: uq_dh_discount_header_uuid

-- DROP INDEX IF EXISTS public.uq_dh_discount_header_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_discount_header_uuid
    ON public.dh_discount_header USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
