-- Table: public.audit_trace

-- DROP TABLE IF EXISTS public.audit_trace;

CREATE TABLE IF NOT EXISTS public.audit_trace
(
    workflow_id character varying(100) COLLATE pg_catalog."default",
    is_active boolean,
    commit_offset character varying(250) COLLATE pg_catalog."default",
    transaction_start_time timestamp with time zone,
    transaction_end_time timestamp with time zone,
    error_stack character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    commit_status character varying(50) COLLATE pg_catalog."default",
    user_id character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    business_id character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT pk_audit_trace PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_audit_trace UNIQUE (workflow_id, business_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.audit_trace
    OWNER to postgres;

REVOKE ALL ON TABLE public.audit_trace FROM "simai-dev";

GRANT ALL ON TABLE public.audit_trace TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.audit_trace TO "simai-dev";

GRANT ALL ON TABLE public.audit_trace TO "simai-devops";

GRANT ALL ON TABLE public.audit_trace TO simai_app;

GRANT ALL ON TABLE public.audit_trace TO zabbix;
-- Index: idx_audit_trace_business_id

-- DROP INDEX IF EXISTS public.idx_audit_trace_business_id;

CREATE INDEX IF NOT EXISTS idx_audit_trace_business_id
    ON public.audit_trace USING btree
    (business_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_audit_trace_uuid

-- DROP INDEX IF EXISTS public.uq_audit_trace_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_audit_trace_uuid
    ON public.audit_trace USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
