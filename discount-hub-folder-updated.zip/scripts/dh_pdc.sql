-- Table: public.dh_pdc

-- DROP TABLE IF EXISTS public.dh_pdc;

CREATE TABLE IF NOT EXISTS public.dh_pdc
(
    is_deleted boolean,
    external_instance character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    active_flag character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    region character varying(255) COLLATE pg_catalog."default",
    business_unit character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    pdc character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_dh_pdc PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_pdc UNIQUE (region, business_unit, pdc)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_pdc
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_pdc FROM "simai-dev";

GRANT ALL ON TABLE public.dh_pdc TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_pdc TO "simai-dev";

GRANT ALL ON TABLE public.dh_pdc TO "simai-devops";

GRANT ALL ON TABLE public.dh_pdc TO simai_app;

GRANT ALL ON TABLE public.dh_pdc TO zabbix;
-- Index: uq_dh_pdc_uuid

-- DROP INDEX IF EXISTS public.uq_dh_pdc_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_pdc_uuid
    ON public.dh_pdc USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
