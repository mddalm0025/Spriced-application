-- Table: public.dh_cust_ref_bis_finance_code

-- DROP TABLE IF EXISTS public.dh_cust_ref_bis_finance_code;

CREATE TABLE IF NOT EXISTS public.dh_cust_ref_bis_finance_code
(
    fin_business_desc character varying(255) COLLATE pg_catalog."default",
    inactive_flag character varying(255) COLLATE pg_catalog."default",
    is_deleted boolean,
    fin_business_code character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    source character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_dh_cust_ref_bis_finance_code PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_cust_ref_bis_finance_code UNIQUE (fin_business_code, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_cust_ref_bis_finance_code
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_cust_ref_bis_finance_code FROM "simai-dev";

GRANT ALL ON TABLE public.dh_cust_ref_bis_finance_code TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_cust_ref_bis_finance_code TO "simai-dev";

GRANT ALL ON TABLE public.dh_cust_ref_bis_finance_code TO "simai-devops";

GRANT ALL ON TABLE public.dh_cust_ref_bis_finance_code TO simai_app;

GRANT ALL ON TABLE public.dh_cust_ref_bis_finance_code TO zabbix;
-- Index: uq_dh_cust_ref_bis_finance_code_uuid

-- DROP INDEX IF EXISTS public.uq_dh_cust_ref_bis_finance_code_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_cust_ref_bis_finance_code_uuid
    ON public.dh_cust_ref_bis_finance_code USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
