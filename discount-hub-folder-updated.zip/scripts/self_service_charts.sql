-- Table: public.self_service_charts

-- DROP TABLE IF EXISTS public.self_service_charts;

CREATE TABLE IF NOT EXISTS public.self_service_charts
(
    id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    name character varying(500) COLLATE pg_catalog."default",
    dataset_id character varying(255) COLLATE pg_catalog."default",
    payload jsonb NOT NULL,
    created_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    updated_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT self_service_charts_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.self_service_charts
    OWNER to postgres;

REVOKE ALL ON TABLE public.self_service_charts FROM "simai-dev";

GRANT ALL ON TABLE public.self_service_charts TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.self_service_charts TO "simai-dev";

GRANT ALL ON TABLE public.self_service_charts TO "simai-devops";

GRANT ALL ON TABLE public.self_service_charts TO simai_app;

GRANT ALL ON TABLE public.self_service_charts TO zabbix;
