-- Table: public.dh_part

-- DROP TABLE IF EXISTS public.dh_part;

CREATE TABLE IF NOT EXISTS public.dh_part
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    part_no character varying(25) COLLATE pg_catalog."default",
    part_name character varying(100) COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    source character varying(25) COLLATE pg_catalog."default",
    active_flag character varying(25) COLLATE pg_catalog."default",
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    CONSTRAINT pk_dh_part PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_part UNIQUE (part_no, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_part
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_part FROM "simai-dev";

GRANT ALL ON TABLE public.dh_part TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_part TO "simai-dev";

GRANT ALL ON TABLE public.dh_part TO "simai-devops";

GRANT ALL ON TABLE public.dh_part TO simai_app;

GRANT ALL ON TABLE public.dh_part TO zabbix;
-- Index: uq_dh_part_uuid

-- DROP INDEX IF EXISTS public.uq_dh_part_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_part_uuid
    ON public.dh_part USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
