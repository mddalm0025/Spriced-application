-- Table: public.custom_reference_dr_template

-- DROP TABLE IF EXISTS public.custom_reference_dr_template;

CREATE TABLE IF NOT EXISTS public.custom_reference_dr_template
(
    template_id character varying(255) COLLATE pg_catalog."default",
    discount_type character varying(255) COLLATE pg_catalog."default",
    business_unit character varying(255) COLLATE pg_catalog."default",
    region character varying(255) COLLATE pg_catalog."default",
    pdc character varying(255) COLLATE pg_catalog."default",
    attributes_json jsonb[],
    rules_validations_json jsonb[],
    approval_choice_json character varying(1000) COLLATE pg_catalog."default",
    active_flag boolean,
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_custom_reference_dr_template PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_custom_reference_dr_template UNIQUE (discount_type, business_unit, pdc, template_id, region)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.custom_reference_dr_template
    OWNER to postgres;

REVOKE ALL ON TABLE public.custom_reference_dr_template FROM "simai-dev";

GRANT ALL ON TABLE public.custom_reference_dr_template TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.custom_reference_dr_template TO "simai-dev";

GRANT ALL ON TABLE public.custom_reference_dr_template TO "simai-devops";

GRANT ALL ON TABLE public.custom_reference_dr_template TO simai_app;

GRANT ALL ON TABLE public.custom_reference_dr_template TO zabbix;
-- Index: uq_custom_reference_dr_template_attributes_json

-- DROP INDEX IF EXISTS public.uq_custom_reference_dr_template_attributes_json;

CREATE UNIQUE INDEX IF NOT EXISTS uq_custom_reference_dr_template_attributes_json
    ON public.custom_reference_dr_template USING btree
    (attributes_json ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_custom_reference_dr_template_template_id

-- DROP INDEX IF EXISTS public.uq_custom_reference_dr_template_template_id;

CREATE UNIQUE INDEX IF NOT EXISTS uq_custom_reference_dr_template_template_id
    ON public.custom_reference_dr_template USING btree
    (template_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_custom_reference_dr_template_uuid

-- DROP INDEX IF EXISTS public.uq_custom_reference_dr_template_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_custom_reference_dr_template_uuid
    ON public.custom_reference_dr_template USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
