-- Table: public.event_consumer

-- DROP TABLE IF EXISTS public.event_consumer;

CREATE TABLE IF NOT EXISTS public.event_consumer
(
    notification_type character varying(50) COLLATE pg_catalog."default",
    is_active boolean,
    error jsonb,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(40) COLLATE pg_catalog."default" NOT NULL,
    next_retry_time timestamp with time zone,
    event_id character varying(555) COLLATE pg_catalog."default",
    additional_details jsonb,
    user_id character varying(100) COLLATE pg_catalog."default",
    retry_count integer,
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    status character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT pk_event_consumer PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_event_consumer UNIQUE (event_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.event_consumer
    OWNER to postgres;

REVOKE ALL ON TABLE public.event_consumer FROM "simai-dev";

GRANT ALL ON TABLE public.event_consumer TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.event_consumer TO "simai-dev";

GRANT ALL ON TABLE public.event_consumer TO "simai-devops";

GRANT ALL ON TABLE public.event_consumer TO simai_app;

GRANT ALL ON TABLE public.event_consumer TO zabbix;
-- Index: uq_event_consumer_uuid

-- DROP INDEX IF EXISTS public.uq_event_consumer_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_event_consumer_uuid
    ON public.event_consumer USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
