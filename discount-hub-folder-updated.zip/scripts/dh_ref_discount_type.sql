-- Table: public.dh_ref_discount_type

-- DROP TABLE IF EXISTS public.dh_ref_discount_type;

CREATE TABLE IF NOT EXISTS public.dh_ref_discount_type
(
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    discount_type character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_cu_dh_discount_type PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_cu_dh_discount_type UNIQUE (discount_type),
    CONSTRAINT uq_cols_cu_dh_discount_type UNIQUE (discount_type, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_ref_discount_type
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_ref_discount_type FROM "simai-dev";

GRANT ALL ON TABLE public.dh_ref_discount_type TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_ref_discount_type TO "simai-dev";

GRANT ALL ON TABLE public.dh_ref_discount_type TO "simai-devops";

GRANT ALL ON TABLE public.dh_ref_discount_type TO simai_app;

GRANT ALL ON TABLE public.dh_ref_discount_type TO zabbix;
-- Index: uq_cu_dh_discount_type_discount_type

-- DROP INDEX IF EXISTS public.uq_cu_dh_discount_type_discount_type;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_discount_type_discount_type
    ON public.dh_ref_discount_type USING btree
    (discount_type COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_cu_dh_discount_type_uuid

-- DROP INDEX IF EXISTS public.uq_cu_dh_discount_type_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_discount_type_uuid
    ON public.dh_ref_discount_type USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
