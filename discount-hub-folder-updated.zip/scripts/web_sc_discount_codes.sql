-- Table: public.web_sc_discount_codes

-- DROP TABLE IF EXISTS public.web_sc_discount_codes;

CREATE TABLE IF NOT EXISTS public.web_sc_discount_codes
(
    web_discount_code character varying(100) COLLATE pg_catalog."default",
    web_discount_pct numeric,
    min_days numeric,
    max_days numeric,
    source character varying(100) COLLATE pg_catalog."default",
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_cu_web_sc_discount_codes PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_cu_web_sc_discount_codes UNIQUE (web_discount_code, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.web_sc_discount_codes
    OWNER to postgres;

REVOKE ALL ON TABLE public.web_sc_discount_codes FROM "simai-dev";

GRANT ALL ON TABLE public.web_sc_discount_codes TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.web_sc_discount_codes TO "simai-dev";

GRANT ALL ON TABLE public.web_sc_discount_codes TO "simai-devops";

GRANT ALL ON TABLE public.web_sc_discount_codes TO simai_app;

GRANT ALL ON TABLE public.web_sc_discount_codes TO zabbix;
