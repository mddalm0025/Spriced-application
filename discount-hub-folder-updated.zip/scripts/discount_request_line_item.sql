-- Table: public.discount_request_line_item

-- DROP TABLE IF EXISTS public.discount_request_line_item;

CREATE TABLE IF NOT EXISTS public.discount_request_line_item
(
    line_item_id character varying(255) COLLATE pg_catalog."default",
    discount_id character varying(255) COLLATE pg_catalog."default",
    attributes_values_json jsonb,
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_discount_request_line_item PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_discount_request_line_item UNIQUE (line_item_id),
    CONSTRAINT uq_cols_discount_request_line_item UNIQUE (line_item_id, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.discount_request_line_item
    OWNER to postgres;

REVOKE ALL ON TABLE public.discount_request_line_item FROM "simai-dev";

GRANT ALL ON TABLE public.discount_request_line_item TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.discount_request_line_item TO "simai-dev";

GRANT ALL ON TABLE public.discount_request_line_item TO "simai-devops";

GRANT ALL ON TABLE public.discount_request_line_item TO simai_app;

GRANT ALL ON TABLE public.discount_request_line_item TO zabbix;
-- Index: uq_discount_request_line_item_line_item_id

-- DROP INDEX IF EXISTS public.uq_discount_request_line_item_line_item_id;

CREATE UNIQUE INDEX IF NOT EXISTS uq_discount_request_line_item_line_item_id
    ON public.discount_request_line_item USING btree
    (line_item_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_discount_request_line_item_uuid

-- DROP INDEX IF EXISTS public.uq_discount_request_line_item_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_discount_request_line_item_uuid
    ON public.discount_request_line_item USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
