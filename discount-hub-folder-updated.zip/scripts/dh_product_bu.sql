-- Table: public.dh_product_bu

-- DROP TABLE IF EXISTS public.dh_product_bu;

CREATE TABLE IF NOT EXISTS public.dh_product_bu
(
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    active_flag character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    business_unit character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    product_bu character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_dh_product_bu PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_product_bu UNIQUE (business_unit, product_bu)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_product_bu
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_product_bu FROM "simai-dev";

GRANT ALL ON TABLE public.dh_product_bu TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_product_bu TO "simai-dev";

GRANT ALL ON TABLE public.dh_product_bu TO "simai-devops";

GRANT ALL ON TABLE public.dh_product_bu TO simai_app;

GRANT ALL ON TABLE public.dh_product_bu TO zabbix;
-- Index: uq_dh_product_bu_uuid

-- DROP INDEX IF EXISTS public.uq_dh_product_bu_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_product_bu_uuid
    ON public.dh_product_bu USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
