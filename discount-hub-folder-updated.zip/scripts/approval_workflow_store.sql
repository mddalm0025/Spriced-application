-- Table: public.approval_workflow_store

-- DROP TABLE IF EXISTS public.approval_workflow_store;

CREATE TABLE IF NOT EXISTS public.approval_workflow_store
(
    uuid character varying COLLATE pg_catalog."default" NOT NULL,
    workflows jsonb NOT NULL,
    is_enabled boolean,
    workflow_id character varying COLLATE pg_catalog."default",
    workflow_version character varying COLLATE pg_catalog."default",
    workflow_type character varying COLLATE pg_catalog."default",
    CONSTRAINT approval_workflow_store_pkey PRIMARY KEY (uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.approval_workflow_store
    OWNER to postgres;

REVOKE ALL ON TABLE public.approval_workflow_store FROM "simai-dev";

GRANT ALL ON TABLE public.approval_workflow_store TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.approval_workflow_store TO "simai-dev";

GRANT ALL ON TABLE public.approval_workflow_store TO "simai-devops";

GRANT ALL ON TABLE public.approval_workflow_store TO simai_app;

GRANT ALL ON TABLE public.approval_workflow_store TO zabbix;
