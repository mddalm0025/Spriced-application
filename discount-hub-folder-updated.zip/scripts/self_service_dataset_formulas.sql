-- Table: public.self_service_dataset_formulas

-- DROP TABLE IF EXISTS public.self_service_dataset_formulas;

CREATE TABLE IF NOT EXISTS public.self_service_dataset_formulas
(
    dataset_id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    file_name character varying(500) COLLATE pg_catalog."default",
    payload jsonb NOT NULL,
    created_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    updated_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT self_service_dataset_formulas_pkey PRIMARY KEY (dataset_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.self_service_dataset_formulas
    OWNER to postgres;

REVOKE ALL ON TABLE public.self_service_dataset_formulas FROM "simai-dev";

GRANT ALL ON TABLE public.self_service_dataset_formulas TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.self_service_dataset_formulas TO "simai-dev";

GRANT ALL ON TABLE public.self_service_dataset_formulas TO "simai-devops";

GRANT ALL ON TABLE public.self_service_dataset_formulas TO simai_app;

GRANT ALL ON TABLE public.self_service_dataset_formulas TO zabbix;
