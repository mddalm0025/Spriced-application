-- Table: public.dh_cust_ref_region_code

-- DROP TABLE IF EXISTS public.dh_cust_ref_region_code;

CREATE TABLE IF NOT EXISTS public.dh_cust_ref_region_code
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    region_code character varying(6) COLLATE pg_catalog."default",
    description character varying(35) COLLATE pg_catalog."default",
    source character varying(25) COLLATE pg_catalog."default",
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    CONSTRAINT pk_dh_cust_ref_region_code PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_cust_ref_region_code UNIQUE (source, region_code)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_cust_ref_region_code
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_cust_ref_region_code FROM "simai-dev";

GRANT ALL ON TABLE public.dh_cust_ref_region_code TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_cust_ref_region_code TO "simai-dev";

GRANT ALL ON TABLE public.dh_cust_ref_region_code TO "simai-devops";

GRANT ALL ON TABLE public.dh_cust_ref_region_code TO simai_app;

GRANT ALL ON TABLE public.dh_cust_ref_region_code TO zabbix;
-- Index: uq_dh_cust_ref_region_code_uuid

-- DROP INDEX IF EXISTS public.uq_dh_cust_ref_region_code_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_cust_ref_region_code_uuid
    ON public.dh_cust_ref_region_code USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
