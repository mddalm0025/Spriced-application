-- Table: public.ref_country

-- DROP TABLE IF EXISTS public.ref_country;

CREATE TABLE IF NOT EXISTS public.ref_country
(
    country_code character varying(30) COLLATE pg_catalog."default" NOT NULL,
    country_name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    currency_name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    description character varying(200) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    CONSTRAINT pk_ref_country PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_ref_country UNIQUE (country_code, country_name)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.ref_country
    OWNER to postgres;

REVOKE ALL ON TABLE public.ref_country FROM "simai-dev";

GRANT ALL ON TABLE public.ref_country TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.ref_country TO "simai-dev";

GRANT ALL ON TABLE public.ref_country TO "simai-devops";

GRANT ALL ON TABLE public.ref_country TO simai_app;

GRANT ALL ON TABLE public.ref_country TO zabbix;
-- Index: uq_ref_country_uuid

-- DROP INDEX IF EXISTS public.uq_ref_country_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_ref_country_uuid
    ON public.ref_country USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
