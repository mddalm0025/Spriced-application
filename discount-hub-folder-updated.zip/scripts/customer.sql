-- Table: public.customer

-- DROP TABLE IF EXISTS public.customer;

CREATE TABLE IF NOT EXISTS public.customer
(
    customer_id character varying(255) COLLATE pg_catalog."default",
    customer_name character varying(255) COLLATE pg_catalog."default",
    customer_type character varying(255) COLLATE pg_catalog."default",
    customer_no character varying(255) COLLATE pg_catalog."default",
    subsidiary jsonb,
    source character varying(255) COLLATE pg_catalog."default",
    is_deleted boolean DEFAULT false,
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_dh_customer PRIMARY KEY (uuid),
    CONSTRAINT uq_dh_customer_customer_id_source UNIQUE (customer_id, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.customer
    OWNER to postgres;

REVOKE ALL ON TABLE public.customer FROM "simai-dev";

GRANT ALL ON TABLE public.customer TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.customer TO "simai-dev";

GRANT ALL ON TABLE public.customer TO "simai-devops";

GRANT ALL ON TABLE public.customer TO simai_app;

GRANT ALL ON TABLE public.customer TO zabbix;
-- Index: uq_dh_customer_uuid

-- DROP INDEX IF EXISTS public.uq_dh_customer_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_customer_uuid
    ON public.customer USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
