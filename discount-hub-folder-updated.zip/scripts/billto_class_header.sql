-- Table: public.billto_class_header

-- DROP TABLE IF EXISTS public.billto_class_header;

CREATE TABLE IF NOT EXISTS public.billto_class_header
(
    class_code character varying(255) COLLATE pg_catalog."default",
    class_name character varying(255) COLLATE pg_catalog."default",
    region character varying(255) COLLATE pg_catalog."default",
    country character varying(255) COLLATE pg_catalog."default",
    class_owner character varying(255) COLLATE pg_catalog."default",
    notes character varying(255) COLLATE pg_catalog."default",
    source character varying(255) COLLATE pg_catalog."default",
    class_status character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    CONSTRAINT pk_billto_class_header PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_billto_class_header UNIQUE (country, source, region, class_code)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.billto_class_header
    OWNER to postgres;

REVOKE ALL ON TABLE public.billto_class_header FROM "simai-dev";

GRANT ALL ON TABLE public.billto_class_header TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.billto_class_header TO "simai-dev";

GRANT ALL ON TABLE public.billto_class_header TO "simai-devops";

GRANT ALL ON TABLE public.billto_class_header TO simai_app;

GRANT ALL ON TABLE public.billto_class_header TO zabbix;
-- Index: uq_billto_class_header_uuid

-- DROP INDEX IF EXISTS public.uq_billto_class_header_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_billto_class_header_uuid
    ON public.billto_class_header USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
