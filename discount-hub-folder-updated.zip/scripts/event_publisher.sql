-- Table: public.event_publisher

-- DROP TABLE IF EXISTS public.event_publisher;

CREATE TABLE IF NOT EXISTS public.event_publisher
(
    is_active boolean,
    event_id character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    message jsonb,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(40) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_event_publisher PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_event_publisher UNIQUE (event_id),
    CONSTRAINT uq_cols_event_publisher UNIQUE (event_id, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.event_publisher
    OWNER to postgres;

REVOKE ALL ON TABLE public.event_publisher FROM "simai-dev";

GRANT ALL ON TABLE public.event_publisher TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.event_publisher TO "simai-dev";

GRANT ALL ON TABLE public.event_publisher TO "simai-devops";

GRANT ALL ON TABLE public.event_publisher TO simai_app;

GRANT ALL ON TABLE public.event_publisher TO zabbix;
-- Index: uq_event_publisher_event_id

-- DROP INDEX IF EXISTS public.uq_event_publisher_event_id;

CREATE UNIQUE INDEX IF NOT EXISTS uq_event_publisher_event_id
    ON public.event_publisher USING btree
    (event_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_event_publisher_uuid

-- DROP INDEX IF EXISTS public.uq_event_publisher_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_event_publisher_uuid
    ON public.event_publisher USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
