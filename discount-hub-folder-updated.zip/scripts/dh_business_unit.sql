-- Table: public.dh_business_unit

-- DROP TABLE IF EXISTS public.dh_business_unit;

CREATE TABLE IF NOT EXISTS public.dh_business_unit
(
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    active_flag character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    business_unit character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_dh_business_unit PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_business_unit UNIQUE (business_unit),
    CONSTRAINT uq_cols_dh_business_unit UNIQUE (business_unit, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_business_unit
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_business_unit FROM "simai-dev";

GRANT ALL ON TABLE public.dh_business_unit TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_business_unit TO "simai-dev";

GRANT ALL ON TABLE public.dh_business_unit TO "simai-devops";

GRANT ALL ON TABLE public.dh_business_unit TO simai_app;

GRANT ALL ON TABLE public.dh_business_unit TO zabbix;
-- Index: uq_dh_business_unit_business_unit

-- DROP INDEX IF EXISTS public.uq_dh_business_unit_business_unit;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_business_unit_business_unit
    ON public.dh_business_unit USING btree
    (business_unit COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_dh_business_unit_uuid

-- DROP INDEX IF EXISTS public.uq_dh_business_unit_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_business_unit_uuid
    ON public.dh_business_unit USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
