-- Table: public.dh_cust_sup_discount_header

-- DROP TABLE IF EXISTS public.dh_cust_sup_discount_header;

CREATE TABLE IF NOT EXISTS public.dh_cust_sup_discount_header
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    discount_request_id character varying(100) COLLATE pg_catalog."default",
    confidential boolean,
    background text COLLATE pg_catalog."default",
    required_value_exchange text COLLATE pg_catalog."default",
    risk_of_doing_nothing text COLLATE pg_catalog."default",
    strategy_rationale text COLLATE pg_catalog."default",
    attachment text COLLATE pg_catalog."default",
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    data_history jsonb,
    version_no integer,
    mark_for_deletion boolean,
    is_current boolean,
    CONSTRAINT pk_dh_cust_sup_discount_header PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_cust_sup_discount_header UNIQUE (discount_request_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_cust_sup_discount_header
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_cust_sup_discount_header FROM "simai-dev";

GRANT ALL ON TABLE public.dh_cust_sup_discount_header TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_cust_sup_discount_header TO "simai-dev";

GRANT ALL ON TABLE public.dh_cust_sup_discount_header TO "simai-devops";

GRANT ALL ON TABLE public.dh_cust_sup_discount_header TO simai_app;

GRANT ALL ON TABLE public.dh_cust_sup_discount_header TO zabbix;
-- Index: uq_dh_cust_sup_discount_header_uuid

-- DROP INDEX IF EXISTS public.uq_dh_cust_sup_discount_header_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_cust_sup_discount_header_uuid
    ON public.dh_cust_sup_discount_header USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
