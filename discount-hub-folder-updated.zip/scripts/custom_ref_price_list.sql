-- Table: public.custom_ref_price_list

-- DROP TABLE IF EXISTS public.custom_ref_price_list;

CREATE TABLE IF NOT EXISTS public.custom_ref_price_list
(
    price_list_name character varying(200) COLLATE pg_catalog."default",
    start_date character varying(255) COLLATE pg_catalog."default",
    end_date character varying(255) COLLATE pg_catalog."default",
    source character varying(250) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    is_deleted boolean DEFAULT false,
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    CONSTRAINT pk_custom_ref_price_list PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_custom_ref_price_list UNIQUE (price_list_name, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.custom_ref_price_list
    OWNER to postgres;

REVOKE ALL ON TABLE public.custom_ref_price_list FROM "simai-dev";

GRANT ALL ON TABLE public.custom_ref_price_list TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.custom_ref_price_list TO "simai-dev";

GRANT ALL ON TABLE public.custom_ref_price_list TO "simai-devops";

GRANT ALL ON TABLE public.custom_ref_price_list TO simai_app;

GRANT ALL ON TABLE public.custom_ref_price_list TO zabbix;
-- Index: uq_custom_ref_price_list_uuid

-- DROP INDEX IF EXISTS public.uq_custom_ref_price_list_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_custom_ref_price_list_uuid
    ON public.custom_ref_price_list USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
