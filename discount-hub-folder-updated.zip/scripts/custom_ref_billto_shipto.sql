-- Table: public.custom_ref_billto_shipto

-- DROP TABLE IF EXISTS public.custom_ref_billto_shipto;

CREATE TABLE IF NOT EXISTS public.custom_ref_billto_shipto
(
    customer_id character varying(255) COLLATE pg_catalog."default",
    customer_no character varying(255) COLLATE pg_catalog."default",
    customer_ship_to_location text COLLATE pg_catalog."default",
    abbreviation text COLLATE pg_catalog."default",
    cwp_discount_code character varying(255) COLLATE pg_catalog."default",
    source character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    is_deleted boolean DEFAULT false,
    updated_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    CONSTRAINT pk_custom_ref_billto_shipto PRIMARY KEY (uuid),
    CONSTRAINT uq_custom_ref_billto_shipto_abbreviation_source UNIQUE (abbreviation, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.custom_ref_billto_shipto
    OWNER to postgres;

REVOKE ALL ON TABLE public.custom_ref_billto_shipto FROM "simai-dev";

GRANT ALL ON TABLE public.custom_ref_billto_shipto TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.custom_ref_billto_shipto TO "simai-dev";

GRANT ALL ON TABLE public.custom_ref_billto_shipto TO "simai-devops";

GRANT ALL ON TABLE public.custom_ref_billto_shipto TO simai_app;

GRANT ALL ON TABLE public.custom_ref_billto_shipto TO zabbix;
-- Index: uq_custom_ref_billto_shipto_uuid

-- DROP INDEX IF EXISTS public.uq_custom_ref_billto_shipto_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_custom_ref_billto_shipto_uuid
    ON public.custom_ref_billto_shipto USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
