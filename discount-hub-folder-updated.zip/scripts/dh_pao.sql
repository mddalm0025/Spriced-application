-- Table: public.dh_pao

-- DROP TABLE IF EXISTS public.dh_pao;

CREATE TABLE IF NOT EXISTS public.dh_pao
(
    pricing_admin_owner character varying(255) COLLATE pg_catalog."default",
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    active_flag character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    business_unit character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_dh_pao PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_pao UNIQUE (pricing_admin_owner, business_unit)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_pao
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_pao FROM "simai-dev";

GRANT ALL ON TABLE public.dh_pao TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_pao TO "simai-dev";

GRANT ALL ON TABLE public.dh_pao TO "simai-devops";

GRANT ALL ON TABLE public.dh_pao TO simai_app;

GRANT ALL ON TABLE public.dh_pao TO zabbix;
-- Index: uq_dh_pao_uuid

-- DROP INDEX IF EXISTS public.uq_dh_pao_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_pao_uuid
    ON public.dh_pao USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
