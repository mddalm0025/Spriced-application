-- Table: public.entity_store

-- DROP TABLE IF EXISTS public.entity_store;

CREATE TABLE IF NOT EXISTS public.entity_store
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    payload jsonb NOT NULL,
    is_enabled boolean,
    entity_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean,
    deam_read jsonb,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_entity_store PRIMARY KEY (entity_name)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.entity_store
    OWNER to postgres;

REVOKE ALL ON TABLE public.entity_store FROM "simai-dev";

GRANT ALL ON TABLE public.entity_store TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.entity_store TO "simai-dev";

GRANT ALL ON TABLE public.entity_store TO "simai-devops";

GRANT ALL ON TABLE public.entity_store TO simai_app;

GRANT ALL ON TABLE public.entity_store TO zabbix;
-- Index: uq_entity_store_entity_name

-- DROP INDEX IF EXISTS public.uq_entity_store_entity_name;

CREATE UNIQUE INDEX IF NOT EXISTS uq_entity_store_entity_name
    ON public.entity_store USING btree
    (entity_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_entity_store_uuid

-- DROP INDEX IF EXISTS public.uq_entity_store_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_entity_store_uuid
    ON public.entity_store USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
