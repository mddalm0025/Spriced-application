-- Table: public.custom_ref_waredisc

-- DROP TABLE IF EXISTS public.custom_ref_waredisc;

CREATE TABLE IF NOT EXISTS public.custom_ref_waredisc
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    cwp_discount_code character varying(255) COLLATE pg_catalog."default",
    cwp_discount_desc character varying(255) COLLATE pg_catalog."default",
    cwp_discount_pct numeric(18,2),
    begin_date character varying(255) COLLATE pg_catalog."default",
    end_date character varying(255) COLLATE pg_catalog."default",
    source character varying(250) COLLATE pg_catalog."default",
    is_deleted boolean DEFAULT false,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    CONSTRAINT pk_custom_ref_waredisc PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_custom_ref_waredisc UNIQUE (cwp_discount_code, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.custom_ref_waredisc
    OWNER to postgres;

REVOKE ALL ON TABLE public.custom_ref_waredisc FROM "simai-dev";

GRANT ALL ON TABLE public.custom_ref_waredisc TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.custom_ref_waredisc TO "simai-dev";

GRANT ALL ON TABLE public.custom_ref_waredisc TO "simai-devops";

GRANT ALL ON TABLE public.custom_ref_waredisc TO simai_app;

GRANT ALL ON TABLE public.custom_ref_waredisc TO zabbix;
