-- Table: public.auth_api_config

-- DROP TABLE IF EXISTS public.auth_api_config;

CREATE TABLE IF NOT EXISTS public.auth_api_config
(
    is_active boolean,
    request_structure jsonb,
    updated_by character varying(255) COLLATE pg_catalog."default",
    response_structure jsonb,
    auth_api_url character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    id integer NOT NULL,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_auth_api_config PRIMARY KEY (id),
    CONSTRAINT uq_bk_auth_api_config UNIQUE (id, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.auth_api_config
    OWNER to postgres;

REVOKE ALL ON TABLE public.auth_api_config FROM "simai-dev";

GRANT ALL ON TABLE public.auth_api_config TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.auth_api_config TO "simai-dev";

GRANT ALL ON TABLE public.auth_api_config TO "simai-devops";

GRANT ALL ON TABLE public.auth_api_config TO simai_app;

GRANT ALL ON TABLE public.auth_api_config TO zabbix;
