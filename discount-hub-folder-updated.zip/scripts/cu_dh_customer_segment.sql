-- Table: public.cu_dh_customer_segment

-- DROP TABLE IF EXISTS public.cu_dh_customer_segment;

CREATE TABLE IF NOT EXISTS public.cu_dh_customer_segment
(
    type_of_customer character varying(100) COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    active_flag character varying(100) COLLATE pg_catalog."default",
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_cu_dh_customer_segment PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_cu_dh_customer_segment UNIQUE (type_of_customer),
    CONSTRAINT uq_cols_cu_dh_customer_segment UNIQUE (type_of_customer, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.cu_dh_customer_segment
    OWNER to postgres;

REVOKE ALL ON TABLE public.cu_dh_customer_segment FROM "simai-dev";

GRANT ALL ON TABLE public.cu_dh_customer_segment TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.cu_dh_customer_segment TO "simai-dev";

GRANT ALL ON TABLE public.cu_dh_customer_segment TO "simai-devops";

GRANT ALL ON TABLE public.cu_dh_customer_segment TO simai_app;

GRANT ALL ON TABLE public.cu_dh_customer_segment TO zabbix;
-- Index: uq_cu_dh_customer_segment_type_of_customer

-- DROP INDEX IF EXISTS public.uq_cu_dh_customer_segment_type_of_customer;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_customer_segment_type_of_customer
    ON public.cu_dh_customer_segment USING btree
    (type_of_customer COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_cu_dh_customer_segment_uuid

-- DROP INDEX IF EXISTS public.uq_cu_dh_customer_segment_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_customer_segment_uuid
    ON public.cu_dh_customer_segment USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
