-- Table: public.dh_ref_channel

-- DROP TABLE IF EXISTS public.dh_ref_channel;

CREATE TABLE IF NOT EXISTS public.dh_ref_channel
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    channel_code character varying(6) COLLATE pg_catalog."default",
    source character varying(25) COLLATE pg_catalog."default",
    channel_desc character varying(200) COLLATE pg_catalog."default",
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    CONSTRAINT pk_dh_ref_channel PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_ref_channel UNIQUE (channel_code, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_ref_channel
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_ref_channel FROM "simai-dev";

GRANT ALL ON TABLE public.dh_ref_channel TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_ref_channel TO "simai-dev";

GRANT ALL ON TABLE public.dh_ref_channel TO "simai-devops";

GRANT ALL ON TABLE public.dh_ref_channel TO simai_app;

GRANT ALL ON TABLE public.dh_ref_channel TO zabbix;
-- Index: uq_dh_ref_channel_uuid

-- DROP INDEX IF EXISTS public.uq_dh_ref_channel_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_ref_channel_uuid
    ON public.dh_ref_channel USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
