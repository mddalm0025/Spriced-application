-- Table: public.billto_class_line

-- DROP TABLE IF EXISTS public.billto_class_line;

CREATE TABLE IF NOT EXISTS public.billto_class_line
(
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    class_code character varying(100) COLLATE pg_catalog."default",
    class_line_id numeric,
    bill_to_code character varying(100) COLLATE pg_catalog."default",
    customer_name character varying(255) COLLATE pg_catalog."default",
    start_date character varying(50) COLLATE pg_catalog."default",
    end_date character varying(50) COLLATE pg_catalog."default",
    bill_line_status character varying(50) COLLATE pg_catalog."default",
    is_deleted boolean,
    created_by character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    CONSTRAINT pk_billto_class_line PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_billto_class_line UNIQUE (class_code, class_line_id, customer_name)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.billto_class_line
    OWNER to postgres;

REVOKE ALL ON TABLE public.billto_class_line FROM "simai-dev";

GRANT ALL ON TABLE public.billto_class_line TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.billto_class_line TO "simai-dev";

GRANT ALL ON TABLE public.billto_class_line TO "simai-devops";

GRANT ALL ON TABLE public.billto_class_line TO simai_app;

GRANT ALL ON TABLE public.billto_class_line TO zabbix;
-- Index: uq_billto_class_line_uuid

-- DROP INDEX IF EXISTS public.uq_billto_class_line_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_billto_class_line_uuid
    ON public.billto_class_line USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
