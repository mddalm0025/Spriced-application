-- Table: public.self_service_semantic_models

-- DROP TABLE IF EXISTS public.self_service_semantic_models;

CREATE TABLE IF NOT EXISTS public.self_service_semantic_models
(
    source_id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    source_type character varying(64) COLLATE pg_catalog."default",
    payload jsonb NOT NULL,
    created_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    updated_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT self_service_semantic_models_pkey PRIMARY KEY (source_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.self_service_semantic_models
    OWNER to postgres;

REVOKE ALL ON TABLE public.self_service_semantic_models FROM "simai-dev";

GRANT ALL ON TABLE public.self_service_semantic_models TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.self_service_semantic_models TO "simai-dev";

GRANT ALL ON TABLE public.self_service_semantic_models TO "simai-devops";

GRANT ALL ON TABLE public.self_service_semantic_models TO simai_app;

GRANT ALL ON TABLE public.self_service_semantic_models TO zabbix;
