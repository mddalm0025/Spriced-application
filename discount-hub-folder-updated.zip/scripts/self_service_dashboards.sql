-- Table: public.self_service_dashboards

-- DROP TABLE IF EXISTS public.self_service_dashboards;

CREATE TABLE IF NOT EXISTS public.self_service_dashboards
(
    id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    name character varying(500) COLLATE pg_catalog."default",
    slug character varying(500) COLLATE pg_catalog."default",
    status character varying(40) COLLATE pg_catalog."default",
    payload jsonb NOT NULL,
    created_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    updated_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    published_at character varying(64) COLLATE pg_catalog."default",
    CONSTRAINT self_service_dashboards_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.self_service_dashboards
    OWNER to postgres;

REVOKE ALL ON TABLE public.self_service_dashboards FROM "simai-dev";

GRANT ALL ON TABLE public.self_service_dashboards TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.self_service_dashboards TO "simai-dev";

GRANT ALL ON TABLE public.self_service_dashboards TO "simai-devops";

GRANT ALL ON TABLE public.self_service_dashboards TO simai_app;

GRANT ALL ON TABLE public.self_service_dashboards TO zabbix;
