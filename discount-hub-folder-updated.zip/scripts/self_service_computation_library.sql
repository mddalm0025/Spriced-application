-- Table: public.self_service_computation_library

-- DROP TABLE IF EXISTS public.self_service_computation_library;

CREATE TABLE IF NOT EXISTS public.self_service_computation_library
(
    id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    kind character varying(64) COLLATE pg_catalog."default",
    name character varying(255) COLLATE pg_catalog."default",
    payload jsonb NOT NULL,
    created_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    updated_at character varying(64) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT self_service_computation_library_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.self_service_computation_library
    OWNER to postgres;

REVOKE ALL ON TABLE public.self_service_computation_library FROM "simai-dev";

GRANT ALL ON TABLE public.self_service_computation_library TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.self_service_computation_library TO "simai-dev";

GRANT ALL ON TABLE public.self_service_computation_library TO "simai-devops";

GRANT ALL ON TABLE public.self_service_computation_library TO simai_app;

GRANT ALL ON TABLE public.self_service_computation_library TO zabbix;
