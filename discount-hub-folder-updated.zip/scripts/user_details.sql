-- Table: public.user_details

-- DROP TABLE IF EXISTS public.user_details;

CREATE TABLE IF NOT EXISTS public.user_details
(
    user_password character varying(255) COLLATE pg_catalog."default",
    user_email character varying(255) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean,
    user_name character varying(255) COLLATE pg_catalog."default",
    roles character varying(255) COLLATE pg_catalog."default",
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    id integer,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_user_details PRIMARY KEY (user_email),
    CONSTRAINT uq_bk_user_details UNIQUE (user_email, uuid),
    CONSTRAINT uq_cols_user_details UNIQUE (user_email, user_name)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.user_details
    OWNER to postgres;

REVOKE ALL ON TABLE public.user_details FROM "simai-dev";

GRANT ALL ON TABLE public.user_details TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.user_details TO "simai-dev";

GRANT ALL ON TABLE public.user_details TO "simai-devops";

GRANT ALL ON TABLE public.user_details TO simai_app;

GRANT ALL ON TABLE public.user_details TO zabbix;
-- Index: uq_user_details_user_email

-- DROP INDEX IF EXISTS public.uq_user_details_user_email;

CREATE UNIQUE INDEX IF NOT EXISTS uq_user_details_user_email
    ON public.user_details USING btree
    (user_email COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_user_details_user_name

-- DROP INDEX IF EXISTS public.uq_user_details_user_name;

CREATE UNIQUE INDEX IF NOT EXISTS uq_user_details_user_name
    ON public.user_details USING btree
    (user_name COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
