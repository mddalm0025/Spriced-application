-- Table: public.dh_region

-- DROP TABLE IF EXISTS public.dh_region;

CREATE TABLE IF NOT EXISTS public.dh_region
(
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    description character varying(255) COLLATE pg_catalog."default",
    short_name character varying(255) COLLATE pg_catalog."default",
    active_flag character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    region character varying(255) COLLATE pg_catalog."default",
    business_unit character varying(255) COLLATE pg_catalog."default",
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    source character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT pk_dh_region PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_dh_region UNIQUE (region, business_unit, source)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.dh_region
    OWNER to postgres;

REVOKE ALL ON TABLE public.dh_region FROM "simai-dev";

GRANT ALL ON TABLE public.dh_region TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.dh_region TO "simai-dev";

GRANT ALL ON TABLE public.dh_region TO "simai-devops";

GRANT ALL ON TABLE public.dh_region TO simai_app;

GRANT ALL ON TABLE public.dh_region TO zabbix;
-- Index: uq_dh_region_uuid

-- DROP INDEX IF EXISTS public.uq_dh_region_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_dh_region_uuid
    ON public.dh_region USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
