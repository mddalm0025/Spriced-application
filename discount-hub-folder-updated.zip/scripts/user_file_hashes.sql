-- Table: public.user_file_hashes

-- DROP TABLE IF EXISTS public.user_file_hashes;

CREATE TABLE IF NOT EXISTS public.user_file_hashes
(
    is_active boolean,
    hash_key character varying(255) COLLATE pg_catalog."default",
    updated_at timestamp with time zone,
    entity_name character varying(255) COLLATE pg_catalog."default",
    user_id character varying(255) COLLATE pg_catalog."default",
    updated_by timestamp with time zone,
    created_at timestamp with time zone,
    final_flag_status character varying(255) COLLATE pg_catalog."default",
    created_date timestamp with time zone,
    updated_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_user_file_hashes PRIMARY KEY (uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.user_file_hashes
    OWNER to postgres;

REVOKE ALL ON TABLE public.user_file_hashes FROM "simai-dev";

GRANT ALL ON TABLE public.user_file_hashes TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.user_file_hashes TO "simai-dev";

GRANT ALL ON TABLE public.user_file_hashes TO "simai-devops";

GRANT ALL ON TABLE public.user_file_hashes TO simai_app;

GRANT ALL ON TABLE public.user_file_hashes TO zabbix;
-- Index: uq_user_file_hashes_uuid

-- DROP INDEX IF EXISTS public.uq_user_file_hashes_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_user_file_hashes_uuid
    ON public.user_file_hashes USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
