-- Table: public.cu_dh_application

-- DROP TABLE IF EXISTS public.cu_dh_application;

CREATE TABLE IF NOT EXISTS public.cu_dh_application
(
    application character varying(100) COLLATE pg_catalog."default",
    description character varying(1000) COLLATE pg_catalog."default",
    active_flag character varying(100) COLLATE pg_catalog."default",
    is_deleted boolean,
    updated_by character varying(255) COLLATE pg_catalog."default",
    updated_date timestamp with time zone,
    created_date timestamp with time zone,
    created_by character varying(255) COLLATE pg_catalog."default",
    uuid character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_cu_dh_application PRIMARY KEY (uuid),
    CONSTRAINT uq_bk_cu_dh_application UNIQUE (application),
    CONSTRAINT uq_cols_cu_dh_application UNIQUE (application, uuid)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.cu_dh_application
    OWNER to postgres;

REVOKE ALL ON TABLE public.cu_dh_application FROM "simai-dev";

GRANT ALL ON TABLE public.cu_dh_application TO postgres;

GRANT TRUNCATE, INSERT, DELETE, SELECT, UPDATE ON TABLE public.cu_dh_application TO "simai-dev";

GRANT ALL ON TABLE public.cu_dh_application TO "simai-devops";

GRANT ALL ON TABLE public.cu_dh_application TO simai_app;

GRANT ALL ON TABLE public.cu_dh_application TO zabbix;
-- Index: uq_cu_dh_application_application

-- DROP INDEX IF EXISTS public.uq_cu_dh_application_application;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_application_application
    ON public.cu_dh_application USING btree
    (application COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uq_cu_dh_application_uuid

-- DROP INDEX IF EXISTS public.uq_cu_dh_application_uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cu_dh_application_uuid
    ON public.cu_dh_application USING btree
    (uuid COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
