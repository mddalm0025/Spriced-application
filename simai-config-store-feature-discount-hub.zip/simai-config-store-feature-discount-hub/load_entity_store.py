#!/usr/bin/env python3

import os
import json
import random
import psycopg2

DB_CONFIG = {
    "host": "localhost",
    "database": "spriced_nrp_test",
    "user": "nrp_app",
    "password": "nrp_app_2026!",
    "port": 5432
}

JSON_DIR = "./spriced-nrp/deams/public"

DISABLED_ENTITIES = {
    "audit_trace",
    "user_file_hashes"
}


def generate_uuid():
    return "".join(random.choices("abcdef0123456789", k=24))


def get_entity_name(payload):
    if isinstance(payload, list) and payload:
        first_item = payload[0]

        if isinstance(first_item, dict):
            return first_item.get("entity")

    if isinstance(payload, dict):
        return payload.get("entity")

    return None


conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()

try:
    print("Truncating entity_store...")
    cur.execute("TRUNCATE TABLE entity_store")

    for file_name in sorted(os.listdir(JSON_DIR)):
        if not file_name.endswith(".json"):
            continue

        file_path = os.path.join(JSON_DIR, file_name)

        with open(file_path, "r", encoding="utf-8") as file:
            payload = json.load(file)

        entity_name = get_entity_name(payload)

        if not entity_name:
            print(f"Skipping {file_name}: entity name not found")
            continue

        uuid = generate_uuid()
        is_enabled = entity_name not in DISABLED_ENTITIES

        cur.execute(
            """
            INSERT INTO entity_store (
                uuid,
                name,
                payload,
                is_enabled
            )
            VALUES (
                %s,
                %s,
                %s::jsonb,
                %s
            )
            """,
            (
                uuid,
                entity_name,
                json.dumps(payload),
                is_enabled
            )
        )

        print(
            f"Inserted {file_name} | "
            f"name={entity_name} | "
            f"is_enabled={is_enabled} | "
            f"uuid={uuid}"
        )

    conn.commit()
    print("Done")

except Exception as error:
    conn.rollback()
    print(f"Import failed: {error}")
    raise

finally:
    cur.close()
    conn.close()
