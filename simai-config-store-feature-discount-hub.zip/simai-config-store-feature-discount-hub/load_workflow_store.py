#!/usr/bin/env python3

import os
import json
import random
import string
import psycopg2

DB_CONFIG = {
    "host": "localhost",
    "database": "spriced_nrp_test",
    "user": "nrp_app",
    "password": "nrp_app_2026!",
    "port" : 5432
}

JSON_DIR = "./spriced-nrp/workflows-stg"

def generate_uuid():
    return ''.join(random.choices('abcdef0123456789', k=24))

conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()

print(" Truncating table...")
cur.execute("TRUNCATE TABLE public.workflow_store")

for file in os.listdir(JSON_DIR):
    if file.endswith(".json"):
        path = os.path.join(JSON_DIR, file)

        with open(path) as f:
            payload = json.load(f)

        uuid = generate_uuid()

        print(f" Inserting {file} with UUID {uuid}")

        cur.execute("""
            INSERT INTO public.workflow_store (uuid, workflows, is_enabled)
            VALUES (%s, %s, %s)
        """, (uuid, json.dumps(payload), True))

conn.commit()
cur.close()
conn.close()

print(" Done")
